package ise.library;

/**
 * Simply calls ListOps to do any work. ListOps handles both Sets and Lists,
 * but it seems like it is nice to have a SetOps and a ListOps.
 * @author Dale Anson
 */
public class SetOps extends ListOps {
}

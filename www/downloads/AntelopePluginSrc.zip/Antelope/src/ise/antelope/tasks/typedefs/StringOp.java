package ise.antelope.tasks.typedefs;

public interface StringOp {
    public String execute(String s);   
}

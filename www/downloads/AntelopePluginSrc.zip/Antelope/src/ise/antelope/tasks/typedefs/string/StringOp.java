package ise.antelope.tasks.typedefs.string;

public interface StringOp {
    public String execute(String s);   
}

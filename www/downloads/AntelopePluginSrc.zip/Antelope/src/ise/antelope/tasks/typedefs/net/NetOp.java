package ise.antelope.tasks.typedefs.net;


public interface NetOp {
    public String getDefaultProperty();
    public String execute();   
}

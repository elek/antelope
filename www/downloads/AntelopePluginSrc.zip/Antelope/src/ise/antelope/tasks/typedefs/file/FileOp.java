package ise.antelope.tasks.typedefs.file;

import java.io.File;

public interface FileOp {
    public String execute(File f);   
}

tasks_readme.txt

AntelopeTasks @@build.num@@

Antelope home page: http://antelope.sourceforge.net

Installation: copy the jar file to ${ant.home}/lib

Full documentation is in the doc directory, point your browser to 
doc/manual/bk03.html.

Complete source code and test cases are in the src directory.

A jar file containing all tasks and ready for use is in the dist directory.



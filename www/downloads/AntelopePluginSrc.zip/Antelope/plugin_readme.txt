plugin_readme.txt

AntelopePlugin 3.2.8

Antelope home page: http://antelope.tigris.org

Download binary plugin and/or source at:
http://antelope.tigris.org/servlets/ProjectDocumentList


Requirements:
Java 1.4 or later
Ant 1.5 or later
jEdit 4.2 or later with Console and ErrorList plugins


Installation:

1. Download the plugin, see link above.
2. Unzip, then cd AntelopePlugin_3.2.8
3. copy Antelope.jar to your jEdit jars directory
4. start jEdit

The jEdit jars directory on Windows is generally: 
c:\Documents and Settings\your_user_name\.jedit\jars

On Linux/Unix it is generally:
/home/your_user_name/.jedit/jars

or

/export/home/your_user_name/.jedit/jars


Building from source:
1. Download the source, see link above.
2. Unzip, then cd AntelopePluginSrc_3.2.8
3. Ensure the location of jedit.jar is set in either build.props or in
build.xml.
4. ant






